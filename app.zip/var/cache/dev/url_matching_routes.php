<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/' => [[['_route' => 'app_', '_controller' => 'App\\Controller\\Controller::index'], null, null, null, false, false, null]],
        '/assignments' => [[['_route' => 'get_assignments', '_controller' => 'App\\Controller\\MicroserviceController::getAssignments'], null, ['GET' => 0], null, false, false, null]],
        '/machines' => [[['_route' => 'get_machines', '_controller' => 'App\\Controller\\MicroserviceController::getMachines'], null, ['GET' => 0], null, false, false, null]],
        '/processes' => [[['_route' => 'get_processes', '_controller' => 'App\\Controller\\MicroserviceController::getProcesses'], null, ['GET' => 0], null, false, false, null]],
        '/process/add' => [[['_route' => 'add_process', '_controller' => 'App\\Controller\\MicroserviceController::addProcess'], null, ['POST' => 0], null, false, false, null]],
        '/machine/add' => [[['_route' => 'add_machine', '_controller' => 'App\\Controller\\MicroserviceController::addMachine'], null, ['POST' => 0], null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
                .'|/process/delete/([^/]++)(*:66)'
                .'|/machine/delete/([^/]++)(*:97)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        35 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        66 => [[['_route' => 'delete_process', '_controller' => 'App\\Controller\\MicroserviceController::deleteProcess'], ['id'], ['DELETE' => 0], null, false, true, null]],
        97 => [
            [['_route' => 'delete_machine', '_controller' => 'App\\Controller\\MicroserviceController::deleteMachine'], ['id'], ['DELETE' => 0], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
